const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const path = require('path');
const admin = require('firebase-admin');

const app = express();

// Redirect root / to login
app.get('/', (req, res) => {
  res.redirect('/login.html');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:true }));
app.use(session({ secret:'supermall-secret', resave:false, saveUninitialized:true }));

// Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(require('./firebase-admin.json'))
});
const db = admin.firestore();

const OWLET_API_KEY = '6a50bc031e6c9d8163d765bda212b242';
const OWLET_API_URL = 'https://the-owlet.com/api/v2';

app.use(express.static(path.join(__dirname,'public')));

// Middleware to check authentication
async function isAuthenticated(req,res,next){
  if(!req.session.user) return res.redirect('/login.html');
  next();
}

// Firebase login via token
app.post('/firebase-login', async (req,res)=>{
  const {token} = req.body;
  try{
    const decoded = await admin.auth().verifyIdToken(token);
    const userRef = db.collection('users').doc(decoded.uid);
    const userDoc = await userRef.get();
    if(!userDoc.exists){
      await userRef.set({uid:decoded.uid,email:decoded.email,balance:0,orders:[]});
    }
    req.session.user = {uid:decoded.uid,email:decoded.email};
    res.json({success:true});
  }catch(err){ res.status(400).json({error:err.message}); }
});

// Logout
app.get('/logout', (req,res)=>{
  req.session.destroy();
  res.redirect('/login.html');
});

// Dashboard
app.get('/dashboard.html', isAuthenticated, (req,res)=>{
  res.sendFile(path.join(__dirname,'public','dashboard.html'));
});

// API Routes
app.post('/api/services', isAuthenticated, async (req,res)=>{
  try{
    const response = await fetch(OWLET_API_URL, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ key: OWLET_API_KEY, action:'services' })
    });
    const data = await response.json();
    res.json(data);
  }catch(err){ res.status(500).json({error:err.message}); }
});

// Add funds
app.post('/api/add-funds', isAuthenticated, async (req,res)=>{
  try{
    const amount = parseFloat(req.body.amount);
    if(isNaN(amount) || amount <= 0) return res.json({success:false, error:'Invalid amount'});

    const userRef = db.collection('users').doc(req.session.user.uid);
    const userDoc = await userRef.get();
    if(!userDoc.exists) return res.json({success:false, error:'User not found'});

    const newBalance = (userDoc.data().balance || 0) + amount;
    await userRef.update({balance: newBalance});
    res.json({success:true, balance:newBalance});
  } catch(err){
    res.json({success:false, error:err.message});
  }
});


app.post('/api/balance', isAuthenticated, async (req,res)=>{
  try{
    const response = await fetch(OWLET_API_URL, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ key: OWLET_API_KEY, action:'balance' })
    });
    const data = await response.json();
    const userRef = db.collection('users').doc(req.session.user.uid);
    await userRef.update({balance:parseFloat(data.balance)});
    res.json(data);
  }catch(err){ res.status(500).json({error:err.message}); }
});

app.post('/api/order', isAuthenticated, async (req,res)=>{
  const {service,link,quantity} = req.body;
  try{
    const response = await fetch(OWLET_API_URL, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ key: OWLET_API_KEY, action:'add', service, link, quantity })
    });
    const data = await response.json();
    const userRef = db.collection('users').doc(req.session.user.uid);
    await userRef.update({
      orders: admin.firestore.FieldValue.arrayUnion({service,link,quantity,orderId:data.order})
    });
    res.json(data);
  }catch(err){ res.status(500).json({error:err.message}); }
});

app.post('/api/leaderboard', isAuthenticated, async (req,res)=>{
  try{
    const usersSnapshot = await db.collection('users').get();
    const leaderboard = [];
    usersSnapshot.forEach(doc=>{
      const u = doc.data();
      leaderboard.push({user:u.email,funds:u.balance});
    });
    leaderboard.sort((a,b)=>b.funds - a.funds);
    res.json(leaderboard);
  }catch(err){ res.status(500).json({error:err.message}); }
});

// Start server
app.listen(3000,()=>console.log('Server running at http://localhost:3000'));
